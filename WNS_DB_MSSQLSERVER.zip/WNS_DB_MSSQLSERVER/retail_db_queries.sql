

-- QUERY 1: How these regions perform within each BU
SELECT
    BU,
    Customers.Region,
    SUM(Quantity) AS TotalQuantity,
    SUM(Revenue) AS TotalRevenue
FROM
    Sales
    INNER JOIN Customers ON Sales.CustomerID = Customers.CustomerID
GROUP BY
    BU,
    Customers.Region
ORDER BY
    BU,
    Customers.Region;

-- QUERY 2: What they are specifically purchasing within each BU
SELECT
    Products.BU,
    ProductName,
    SUM(Quantity) AS TotalQuantity,
    SUM(Revenue) AS TotalRevenue
FROM
    Sales
    INNER JOIN Products ON Sales.ProductID = Products.ProductID
GROUP BY
    Products.BU,
    ProductName
ORDER BY
    Products.BU,
    TotalRevenue DESC;

-- QUERY 3: Cross-shopping – Fashion, Beauty, and Home (3 BUs), and Food and Fashion
-- Fashion, Beauty, and Home
SELECT
    c.CustomerID,
    SUM(CASE WHEN p.BU = 'Fashion' THEN s.Quantity ELSE 0 END) AS FashionQuantity,
    SUM(CASE WHEN p.BU = 'Beauty' THEN s.Quantity ELSE 0 END) AS BeautyQuantity,
    SUM(CASE WHEN p.BU = 'Home' THEN s.Quantity ELSE 0 END) AS HomeQuantity
FROM
    Sales s
    INNER JOIN Customers c ON s.CustomerID = c.CustomerID
    INNER JOIN Products p ON s.ProductID = p.ProductID
WHERE
    p.BU IN ('Fashion', 'Beauty', 'Home')
GROUP BY
    c.CustomerID
HAVING
    SUM(CASE WHEN p.BU = 'Fashion' THEN s.Quantity ELSE 0 END) > 0 AND
    SUM(CASE WHEN p.BU = 'Beauty' THEN s.Quantity ELSE 0 END) > 0 AND
    SUM(CASE WHEN p.BU = 'Home' THEN s.Quantity ELSE 0 END) > 0;

-- Food and Fashion
SELECT
    c.CustomerID,
    SUM(CASE WHEN p.BU = 'Food' THEN s.Quantity ELSE 0 END) AS FoodQuantity,
    SUM(CASE WHEN p.BU = 'Fashion' THEN s.Quantity ELSE 0 END) AS FashionQuantity
FROM
    Sales s
    INNER JOIN Customers c ON s.CustomerID = c.CustomerID
    INNER JOIN Products p ON s.ProductID = p.ProductID
WHERE
    p.BU IN ('Food', 'Fashion')
GROUP BY
    c.CustomerID
HAVING
    SUM(CASE WHEN p.BU = 'Food' THEN s.Quantity ELSE 0 END) > 0 AND
    SUM(CASE WHEN p.BU = 'Fashion' THEN s.Quantity ELSE 0 END) > 0;

-- QUERY 4: Within each BU – what do they regularly shop and which products bring in the most amount of customers and sales
SELECT
    Products.BU,
    ProductName,
    COUNT(DISTINCT CustomerID) AS NumCustomers,
    SUM(Quantity) AS TotalQuantity,
    SUM(Revenue) AS TotalRevenue
FROM
    Sales
    INNER JOIN Products ON Sales.ProductID = Products.ProductID
GROUP BY
    Products.BU,
    ProductName
ORDER BY
    Products.BU,
    NumCustomers DESC,
    TotalRevenue DESC;
